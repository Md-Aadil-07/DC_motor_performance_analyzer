#ifndef __MW_C28XX_PIE_H__
#define __MW_C28XX_PIE_H__
#define PIEMASK0                       64
#define IFRMASK                        1
#endif                                 /* MW_C28XX_PIE_H */
