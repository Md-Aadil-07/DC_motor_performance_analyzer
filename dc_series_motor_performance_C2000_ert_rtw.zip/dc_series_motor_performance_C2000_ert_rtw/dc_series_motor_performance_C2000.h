/*
 * File: dc_series_motor_performance_C2000.h
 *
 * Code generated for Simulink model 'dc_series_motor_performance_C2000'.
 *
 * Model version                  : 16.4
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Sat Dec 21 09:56:25 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef dc_series_motor_performance_C2000_h_
#define dc_series_motor_performance_C2000_h_
#ifndef dc_series_motor_performance_C2000_COMMON_INCLUDES_
#define dc_series_motor_performance_C2000_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "c2000BoardSupport.h"
#include "F2802x_Device.h"
#include "f2802x_examples.h"
#endif                  /* dc_series_motor_performance_C2000_COMMON_INCLUDES_ */

#include <string.h>
#include <stddef.h>
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#define dc_series_motor_performance_C2000_M (rtM)

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  real_T linecurrent1;                 /* '<Root>/line current 1' */
  real_T speed;                        /* '<Root>/speed ' */
  real_T voltage;                      /* '<Root>/voltage' */
} DW;

/* Real-time Model Data Structure */
struct tag_RTM {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block signals and states (default storage) */
extern DW rtDW;

/* Model entry point functions */
extern void dc_series_motor_performance_C2000_initialize(void);
extern void dc_series_motor_performance_C2000_step(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<Root>/ ' : Unused code path elimination
 * Block '<Root>/  ' : Unused code path elimination
 * Block '<Root>/2 pi' : Unused code path elimination
 * Block '<Root>/Clock' : Unused code path elimination
 * Block '<Root>/Constant' : Unused code path elimination
 * Block '<Root>/Eb1' : Unused code path elimination
 * Block '<Root>/Eff1 ' : Unused code path elimination
 * Block '<Root>/Eff2 ' : Unused code path elimination
 * Block '<Root>/Efficiency ' : Unused code path elimination
 * Block '<Root>/Input power' : Unused code path elimination
 * Block '<S1>/Abs' : Unused code path elimination
 * Block '<S1>/Subtract' : Unused code path elimination
 * Block '<Root>/Output power' : Unused code path elimination
 * Block '<S2>/Add' : Unused code path elimination
 * Block '<S2>/Constant' : Unused code path elimination
 * Block '<S2>/Divide' : Unused code path elimination
 * Block '<S2>/Radius' : Unused code path elimination
 * Block '<S2>/Thickness' : Unused code path elimination
 * Block '<S2>/gain' : Unused code path elimination
 * Block '<Root>/Torque' : Unused code path elimination
 * Block '<Root>/Ttime' : Unused code path elimination
 * Block '<Root>/change in input power ' : Unused code path elimination
 * Block '<Root>/change in output power' : Unused code path elimination
 * Block '<Root>/change in torqe' : Unused code path elimination
 * Block '<Root>/eff' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'dc_series_motor_performance_C2000'
 * '<S1>'   : 'dc_series_motor_performance_C2000/Mechanical Load'
 * '<S2>'   : 'dc_series_motor_performance_C2000/Radius'
 */
#endif                                /* dc_series_motor_performance_C2000_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
