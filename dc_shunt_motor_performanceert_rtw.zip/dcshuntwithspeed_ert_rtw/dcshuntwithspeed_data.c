/*
 * File: dcshuntwithspeed_data.c
 *
 * Code generated for Simulink model 'dcshuntwithspeed'.
 *
 * Model version                  : 16.13
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Sat Dec 21 09:38:00 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "dcshuntwithspeed.h"

/* Block parameters (default storage) */
P_dcshuntwithspeed_T dcshuntwithspeed_P = {
  /* Variable: radius
   * Referenced by: '<S2>/radius'
   */
  0.113,

  /* Variable: thickness_of_belt
   * Referenced by: '<S2>/thickness'
   */
  0.005,

  /* Expression: 2
   * Referenced by: '<S2>/Constant'
   */
  2.0,

  /* Expression: 9.81
   * Referenced by: '<S2>/gain'
   */
  9.81,

  /* Expression: 6.28
   * Referenced by: '<Root>/2 * pi'
   */
  6.28,

  /* Expression: 60
   * Referenced by: '<Root>/Constant'
   */
  60.0,

  /* Expression: 0.325
   * Referenced by: '<Root>/gain1'
   */
  0.325,

  /* Expression: 100
   * Referenced by: '<Root>/% conversion'
   */
  100.0,

  /* Computed Parameter: RPS_Gain
   * Referenced by: '<Root>/RPS'
   */
  54526U
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
