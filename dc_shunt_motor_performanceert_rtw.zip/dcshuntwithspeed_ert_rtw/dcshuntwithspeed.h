/*
 * File: dcshuntwithspeed.h
 *
 * Code generated for Simulink model 'dcshuntwithspeed'.
 *
 * Model version                  : 16.13
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Sat Dec 21 09:38:00 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef dcshuntwithspeed_h_
#define dcshuntwithspeed_h_
#ifndef dcshuntwithspeed_COMMON_INCLUDES_
#define dcshuntwithspeed_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "c2000BoardSupport.h"
#include "F2802x_Device.h"
#include "f2802x_examples.h"
#endif                                 /* dcshuntwithspeed_COMMON_INCLUDES_ */

#include "dcshuntwithspeed_types.h"
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Torque;                       /* '<Root>/Torque' */
  real_T Divide2;                      /* '<Root>/Divide2' */
  real_T Divide;                       /* '<Root>/Divide' */
  real_T linecurrent;                  /* '<Root>/line current ' */
  real_T gain1;                        /* '<Root>/gain1' */
  real_T voltage;                      /* '<Root>/voltage' */
  real_T Inputpower;                   /* '<Root>/Input power' */
  real_T conversion;                   /* '<Root>/% conversion' */
  real_T Clock;                        /* '<Root>/Clock' */
  uint32_T RPS;                        /* '<Root>/RPS' */
  uint16_T speed;                      /* '<Root>/speed' */
  uint16_T armaturecurrent;            /* '<Root>/armaturecurrent' */
} B_dcshuntwithspeed_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } _PWORK;                            /* '<Root>/ ' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } _PWORK_m;                          /* '<Root>/  ' */

  struct {
    void *LoggedData;
  } BackEMF_PWORK;                     /* '<Root>/Back EMF' */

  struct {
    void *LoggedData[4];
  } Eb1_PWORK;                         /* '<Root>/Eb1' */

  struct {
    void *LoggedData;
  } Efficiency_PWORK;                  /* '<Root>/Efficiency ' */

  struct {
    void *LoggedData;
  } changeininputpower_PWORK;          /* '<Root>/change in input power ' */

  struct {
    void *LoggedData;
  } changeinoutputpower_PWORK;         /* '<Root>/change in output power' */

  struct {
    void *LoggedData;
  } changeintorqe_PWORK;               /* '<Root>/change in torqe' */

  struct {
    void *LoggedData;
  } Ttime_PWORK;                       /* '<Root>/Ttime' */

  struct {
    int_T PrevIndex;
  } _IWORK;                            /* '<Root>/ ' */

  struct {
    int_T PrevIndex;
  } _IWORK_p;                          /* '<Root>/  ' */
} DW_dcshuntwithspeed_T;

/* Parameters (default storage) */
struct P_dcshuntwithspeed_T_ {
  real_T radius;                       /* Variable: radius
                                        * Referenced by: '<S2>/radius'
                                        */
  real_T thickness_of_belt;            /* Variable: thickness_of_belt
                                        * Referenced by: '<S2>/thickness'
                                        */
  real_T Constant_Value;               /* Expression: 2
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T gain_Gain;                    /* Expression: 9.81
                                        * Referenced by: '<S2>/gain'
                                        */
  real_T upi_Gain;                     /* Expression: 6.28
                                        * Referenced by: '<Root>/2 * pi'
                                        */
  real_T Constant_Value_k;             /* Expression: 60
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T gain1_Gain;                   /* Expression: 0.325
                                        * Referenced by: '<Root>/gain1'
                                        */
  real_T conversion_Gain;              /* Expression: 100
                                        * Referenced by: '<Root>/% conversion'
                                        */
  uint16_T RPS_Gain;                   /* Computed Parameter: RPS_Gain
                                        * Referenced by: '<Root>/RPS'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_dcshuntwithspeed_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_dcshuntwithspeed_T dcshuntwithspeed_P;

/* Block signals (default storage) */
extern B_dcshuntwithspeed_T dcshuntwithspeed_B;

/* Block states (default storage) */
extern DW_dcshuntwithspeed_T dcshuntwithspeed_DW;

/* Model entry point functions */
extern void dcshuntwithspeed_initialize(void);
extern void dcshuntwithspeed_step(void);
extern void dcshuntwithspeed_terminate(void);

/* Real-time Model object */
extern RT_MODEL_dcshuntwithspeed_T *const dcshuntwithspeed_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'dcshuntwithspeed'
 * '<S1>'   : 'dcshuntwithspeed/Mechanical Load'
 * '<S2>'   : 'dcshuntwithspeed/Radius'
 */
#endif                                 /* dcshuntwithspeed_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
