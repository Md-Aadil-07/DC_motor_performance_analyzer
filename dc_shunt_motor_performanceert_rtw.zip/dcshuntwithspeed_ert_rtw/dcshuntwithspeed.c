/*
 * File: dcshuntwithspeed.c
 *
 * Code generated for Simulink model 'dcshuntwithspeed'.
 *
 * Model version                  : 16.13
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Sat Dec 21 09:38:00 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "dcshuntwithspeed.h"
#include <math.h>
#include "rtwtypes.h"
#include "dcshuntwithspeed_private.h"
#include <string.h>
#include "dcshuntwithspeed_dt.h"

/* Block signals (default storage) */
B_dcshuntwithspeed_T dcshuntwithspeed_B;

/* Block states (default storage) */
DW_dcshuntwithspeed_T dcshuntwithspeed_DW;

/* Real-time model */
static RT_MODEL_dcshuntwithspeed_T dcshuntwithspeed_M_;
RT_MODEL_dcshuntwithspeed_T *const dcshuntwithspeed_M = &dcshuntwithspeed_M_;

#ifndef __TMS320C28XX_CLA__

uint16_T MW_adcInitFlag = 0;

#endif

/* Model step function */
void dcshuntwithspeed_step(void)
{
  /* local block i/o variables */
  real_T rtb_Outputpower;
  real_T rtb_Abs;

  /* S-Function (c2802xadc): '<Root>/speed' */
  {
    /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
    /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
    AdcRegs.ADCSOCFRC1.bit.SOC3 = 1U;

    /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

    asm(" RPT #22|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

    real32_T wait_index;
    for (wait_index= 3; wait_index > 0; wait_index--)
      __mnop();

#endif

    dcshuntwithspeed_B.speed = (AdcResult.ADCRESULT3);
  }

  /* Gain: '<Root>/RPS' */
  dcshuntwithspeed_B.RPS = (uint32_T)dcshuntwithspeed_P.RPS_Gain *
    dcshuntwithspeed_B.speed;

  /* FromWorkspace: '<Root>/ ' */
  {
    real_T *pDataValues = (real_T *) dcshuntwithspeed_DW._PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) dcshuntwithspeed_DW._PWORK.TimePtr;
    int_T currTimeIndex = dcshuntwithspeed_DW._IWORK.PrevIndex;
    real_T t = ((dcshuntwithspeed_M->Timing.clockTick1) * 0.001);

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[4]) {
      currTimeIndex = 3;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    dcshuntwithspeed_DW._IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_Abs = pDataValues[currTimeIndex];
        } else {
          rtb_Abs = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex = currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_Abs = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 5;
      }
    }
  }

  /* FromWorkspace: '<Root>/  ' */
  {
    real_T *pDataValues = (real_T *) dcshuntwithspeed_DW._PWORK_m.DataPtr;
    real_T *pTimeValues = (real_T *) dcshuntwithspeed_DW._PWORK_m.TimePtr;
    int_T currTimeIndex = dcshuntwithspeed_DW._IWORK_p.PrevIndex;
    real_T t = ((dcshuntwithspeed_M->Timing.clockTick1) * 0.001);

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[4]) {
      currTimeIndex = 3;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    dcshuntwithspeed_DW._IWORK_p.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_Outputpower = pDataValues[currTimeIndex];
        } else {
          rtb_Outputpower = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex = currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        rtb_Outputpower = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 5;
      }
    }
  }

  /* Abs: '<S1>/Abs' incorporates:
   *  Sum: '<S1>/Subtract'
   */
  rtb_Abs -= rtb_Outputpower;
  rtb_Abs = fabs(rtb_Abs);

  /* Product: '<Root>/Torque' incorporates:
   *  Constant: '<S2>/Constant'
   *  Constant: '<S2>/radius'
   *  Constant: '<S2>/thickness'
   *  Gain: '<S2>/gain'
   *  Product: '<S2>/Divide'
   *  Sum: '<S2>/Add'
   */
  dcshuntwithspeed_B.Torque = (dcshuntwithspeed_P.thickness_of_belt /
    dcshuntwithspeed_P.Constant_Value + dcshuntwithspeed_P.radius) *
    dcshuntwithspeed_P.gain_Gain * rtb_Abs;

  /* Product: '<Root>/Output power' incorporates:
   *  Gain: '<Root>/RPS'
   */
  rtb_Outputpower = (real_T)dcshuntwithspeed_B.RPS * 1.9073486328125E-6 *
    dcshuntwithspeed_B.Torque;

  /* Product: '<Root>/Divide2' incorporates:
   *  Constant: '<Root>/Constant'
   *  Gain: '<Root>/2 * pi'
   */
  dcshuntwithspeed_B.Divide2 = dcshuntwithspeed_P.upi_Gain * rtb_Outputpower /
    dcshuntwithspeed_P.Constant_Value_k;

  /* S-Function (c2802xadc): '<Root>/armaturecurrent' */
  {
    /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
    /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
    AdcRegs.ADCSOCFRC1.bit.SOC0 = 1U;

    /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

    asm(" RPT #22|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

    real32_T wait_index;
    for (wait_index= 3; wait_index > 0; wait_index--)
      __mnop();

#endif

    dcshuntwithspeed_B.armaturecurrent = (AdcResult.ADCRESULT0);
  }

  /* Product: '<Root>/Divide' */
  dcshuntwithspeed_B.Divide = dcshuntwithspeed_B.Divide2 / (real_T)
    dcshuntwithspeed_B.armaturecurrent;

  /* S-Function (c2802xadc): '<Root>/line current ' */
  {
    /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
    /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
    AdcRegs.ADCSOCFRC1.bit.SOC2 = 1U;

    /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

    asm(" RPT #22|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

    real32_T wait_index;
    for (wait_index= 3; wait_index > 0; wait_index--)
      __mnop();

#endif

    dcshuntwithspeed_B.linecurrent = (AdcResult.ADCRESULT2);
  }

  /* Gain: '<Root>/gain1' */
  dcshuntwithspeed_B.gain1 = dcshuntwithspeed_P.gain1_Gain *
    dcshuntwithspeed_B.linecurrent;

  /* S-Function (c2802xadc): '<Root>/voltage' */
  {
    /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
    /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
    AdcRegs.ADCSOCFRC1.bit.SOC1 = 1U;

    /* Wait for the period of Sampling window and EOC result to be latched after trigger */
#ifndef __TMS320C28XX_CLA__

    asm(" RPT #22|| NOP");

#endif

#ifdef __TMS320C28XX_CLA__

    real32_T wait_index;
    for (wait_index= 3; wait_index > 0; wait_index--)
      __mnop();

#endif

    dcshuntwithspeed_B.voltage = (AdcResult.ADCRESULT1);
  }

  /* Product: '<Root>/Input power' */
  dcshuntwithspeed_B.Inputpower = dcshuntwithspeed_B.gain1 *
    dcshuntwithspeed_B.voltage;

  /* Gain: '<Root>/% conversion' incorporates:
   *  Product: '<Root>/Divide1'
   */
  dcshuntwithspeed_B.conversion = dcshuntwithspeed_B.Divide2 /
    dcshuntwithspeed_B.Inputpower * dcshuntwithspeed_P.conversion_Gain;

  /* Clock: '<Root>/Clock' */
  dcshuntwithspeed_B.Clock = dcshuntwithspeed_M->Timing.t[0];

  /* External mode */
  rtExtModeUploadCheckTrigger(2);

  {                                    /* Sample time: [0.0s, 0.0s] */
    rtExtModeUpload(0, (real_T)dcshuntwithspeed_M->Timing.t[0]);
  }

  {                                    /* Sample time: [0.001s, 0.0s] */
    rtExtModeUpload(1, (real_T)((dcshuntwithspeed_M->Timing.clockTick1) * 0.001));
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(dcshuntwithspeed_M)!=-1) &&
        !((rtmGetTFinal(dcshuntwithspeed_M)-dcshuntwithspeed_M->Timing.t[0]) >
          dcshuntwithspeed_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(dcshuntwithspeed_M, "Simulation finished");
    }

    if (rtmGetStopRequested(dcshuntwithspeed_M)) {
      rtmSetErrorStatus(dcshuntwithspeed_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  dcshuntwithspeed_M->Timing.t[0] =
    ((time_T)(++dcshuntwithspeed_M->Timing.clockTick0)) *
    dcshuntwithspeed_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.001, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    dcshuntwithspeed_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void dcshuntwithspeed_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)dcshuntwithspeed_M, 0,
                sizeof(RT_MODEL_dcshuntwithspeed_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&dcshuntwithspeed_M->solverInfo,
                          &dcshuntwithspeed_M->Timing.simTimeStep);
    rtsiSetTPtr(&dcshuntwithspeed_M->solverInfo, &rtmGetTPtr(dcshuntwithspeed_M));
    rtsiSetStepSizePtr(&dcshuntwithspeed_M->solverInfo,
                       &dcshuntwithspeed_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&dcshuntwithspeed_M->solverInfo, (&rtmGetErrorStatus
      (dcshuntwithspeed_M)));
    rtsiSetRTModelPtr(&dcshuntwithspeed_M->solverInfo, dcshuntwithspeed_M);
  }

  rtsiSetSimTimeStep(&dcshuntwithspeed_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange(&dcshuntwithspeed_M->solverInfo, false);
  rtsiSetIsContModeFrozen(&dcshuntwithspeed_M->solverInfo, false);
  rtsiSetSolverName(&dcshuntwithspeed_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(dcshuntwithspeed_M, &dcshuntwithspeed_M->Timing.tArray[0]);
  rtmSetTFinal(dcshuntwithspeed_M, 10.0);
  dcshuntwithspeed_M->Timing.stepSize0 = 0.001;

  /* External mode info */
  dcshuntwithspeed_M->Sizes.checksums[0] = (2643159766U);
  dcshuntwithspeed_M->Sizes.checksums[1] = (1520100700U);
  dcshuntwithspeed_M->Sizes.checksums[2] = (3002725618U);
  dcshuntwithspeed_M->Sizes.checksums[3] = (745138409U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    dcshuntwithspeed_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(dcshuntwithspeed_M->extModeInfo,
      &dcshuntwithspeed_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(dcshuntwithspeed_M->extModeInfo,
                        dcshuntwithspeed_M->Sizes.checksums);
    rteiSetTPtr(dcshuntwithspeed_M->extModeInfo, rtmGetTPtr(dcshuntwithspeed_M));
  }

  /* block I/O */
  (void) memset(((void *) &dcshuntwithspeed_B), 0,
                sizeof(B_dcshuntwithspeed_T));

  /* states (dwork) */
  (void) memset((void *)&dcshuntwithspeed_DW, 0,
                sizeof(DW_dcshuntwithspeed_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    dcshuntwithspeed_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 25;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Start for S-Function (c2802xadc): '<Root>/speed' */
  if (MW_adcInitFlag == 0U) {
    InitAdc();
    MW_adcInitFlag = 1U;
  }

  config_ADC_SOC3 ();

  /* Start for FromWorkspace: '<Root>/ ' */
  {
    static real_T pTimeValues0[] = { 0.001, 0.002, 0.003, 0.004, 0.005 } ;

    static real_T pDataValues0[] = { 0.0, 1.8, 5.0, 10.0, 14.0 } ;

    dcshuntwithspeed_DW._PWORK.TimePtr = (void *) pTimeValues0;
    dcshuntwithspeed_DW._PWORK.DataPtr = (void *) pDataValues0;
    dcshuntwithspeed_DW._IWORK.PrevIndex = 0;
  }

  /* Start for FromWorkspace: '<Root>/  ' */
  {
    static real_T pTimeValues0[] = { 0.001, 0.002, 0.003, 0.004, 0.005 } ;

    static real_T pDataValues0[] = { 0.0, 5.0, 14.0, 25.0, 32.0 } ;

    dcshuntwithspeed_DW._PWORK_m.TimePtr = (void *) pTimeValues0;
    dcshuntwithspeed_DW._PWORK_m.DataPtr = (void *) pDataValues0;
    dcshuntwithspeed_DW._IWORK_p.PrevIndex = 0;
  }

  /* Start for S-Function (c2802xadc): '<Root>/armaturecurrent' */
  if (MW_adcInitFlag == 0U) {
    InitAdc();
    MW_adcInitFlag = 1U;
  }

  config_ADC_SOC0 ();

  /* Start for S-Function (c2802xadc): '<Root>/line current ' */
  if (MW_adcInitFlag == 0U) {
    InitAdc();
    MW_adcInitFlag = 1U;
  }

  config_ADC_SOC2 ();

  /* Start for S-Function (c2802xadc): '<Root>/voltage' */
  if (MW_adcInitFlag == 0U) {
    InitAdc();
    MW_adcInitFlag = 1U;
  }

  config_ADC_SOC1 ();
}

/* Model terminate function */
void dcshuntwithspeed_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
