/*
 * File: dcshuntwithspeed.c
 *
 * Code generated for Simulink model 'dcshuntwithspeed'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Thu Mar 28 14:55:16 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "dcshuntwithspeed.h"
#include "dcshuntwithspeed_private.h"
#include "dcshuntwithspeed_dt.h"

/* Block signals (auto storage) */
B_dcshuntwithspeed_T dcshuntwithspeed_B;

/* Block states (auto storage) */
DW_dcshuntwithspeed_T dcshuntwithspeed_DW;

/* Real-time model */
RT_MODEL_dcshuntwithspeed_T dcshuntwithspeed_M_;
RT_MODEL_dcshuntwithspeed_T *const dcshuntwithspeed_M = &dcshuntwithspeed_M_;

/* Model step function */
void dcshuntwithspeed_step(void)
{
  /* Constant: '<Root>/speed' */
  dcshuntwithspeed_B.speed = dcshuntwithspeed_P.speed_Value;

  /* Product: '<Root>/Torque' incorporates:
   *  Abs: '<Root>/Abs'
   *  Constant: '<Root>/Load1'
   *  Constant: '<Root>/Load2'
   *  Constant: '<Root>/Radius'
   *  Constant: '<Root>/Thickness'
   *  Gain: '<Root>/gain'
   *  Sum: '<Root>/Add'
   *  Sum: '<Root>/Subtract'
   */
  dcshuntwithspeed_B.Torque = (dcshuntwithspeed_P.Radius_Value +
    dcshuntwithspeed_P.Thickness_Value) * dcshuntwithspeed_P.gain_Gain * fabs
    (dcshuntwithspeed_P.Load1_Value - dcshuntwithspeed_P.Load2_Value);

  /* Product: '<Root>/Product1' incorporates:
   *  Gain: '<Root>/RPS'
   */
  dcshuntwithspeed_B.Product1 = dcshuntwithspeed_P.RPS_Gain *
    dcshuntwithspeed_B.speed * dcshuntwithspeed_B.Torque;

  /* S-Function (c2802xadc): '<Root>/armaturecurrent1' */
  {
    /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
    /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
    AdcRegs.ADCSOCFRC1.bit.SOC0 = 1;
    asm(" RPT #22 || NOP");
    dcshuntwithspeed_B.armaturecurrent1 = (AdcResult.ADCRESULT0);
  }

  /* Product: '<Root>/Divide' */
  dcshuntwithspeed_B.Divide = dcshuntwithspeed_B.Product1 / (real_T)
    dcshuntwithspeed_B.armaturecurrent1;

  /* S-Function (c2802xadc): '<Root>/line current ' */
  {
    /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
    /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
    AdcRegs.ADCSOCFRC1.bit.SOC2 = 1;
    asm(" RPT #22 || NOP");
    dcshuntwithspeed_B.linecurrent = (AdcResult.ADCRESULT2);
  }

  /* Gain: '<Root>/gain1' */
  dcshuntwithspeed_B.gain1 = dcshuntwithspeed_P.gain1_Gain *
    dcshuntwithspeed_B.linecurrent;

  /* S-Function (c2802xadc): '<Root>/voltage' */
  {
    /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
    /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
    AdcRegs.ADCSOCFRC1.bit.SOC1 = 1;
    asm(" RPT #22 || NOP");
    dcshuntwithspeed_B.voltage = (AdcResult.ADCRESULT1);
  }

  /* Product: '<Root>/Product' */
  dcshuntwithspeed_B.Product = dcshuntwithspeed_B.gain1 *
    dcshuntwithspeed_B.voltage;

  /* Product: '<Root>/Divide1' */
  dcshuntwithspeed_B.Divide1 = dcshuntwithspeed_B.Product1 /
    dcshuntwithspeed_B.Product;

  /* Clock: '<Root>/Clock' */
  dcshuntwithspeed_B.Clock = dcshuntwithspeed_M->Timing.t[0];

  /* External mode */
  rtExtModeUploadCheckTrigger(2);

  {                                    /* Sample time: [0.0s, 0.0s] */
    rtExtModeUpload(0, dcshuntwithspeed_M->Timing.t[0]);
  }

  {                                    /* Sample time: [0.001s, 0.0s] */
    rtExtModeUpload(1, ((dcshuntwithspeed_M->Timing.clockTick1) * 0.001));
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(dcshuntwithspeed_M)!=-1) &&
        !((rtmGetTFinal(dcshuntwithspeed_M)-dcshuntwithspeed_M->Timing.t[0]) >
          dcshuntwithspeed_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(dcshuntwithspeed_M, "Simulation finished");
    }

    if (rtmGetStopRequested(dcshuntwithspeed_M)) {
      rtmSetErrorStatus(dcshuntwithspeed_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  dcshuntwithspeed_M->Timing.t[0] =
    (++dcshuntwithspeed_M->Timing.clockTick0) *
    dcshuntwithspeed_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.001, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    dcshuntwithspeed_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void dcshuntwithspeed_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)dcshuntwithspeed_M, 0,
                sizeof(RT_MODEL_dcshuntwithspeed_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&dcshuntwithspeed_M->solverInfo,
                          &dcshuntwithspeed_M->Timing.simTimeStep);
    rtsiSetTPtr(&dcshuntwithspeed_M->solverInfo, &rtmGetTPtr(dcshuntwithspeed_M));
    rtsiSetStepSizePtr(&dcshuntwithspeed_M->solverInfo,
                       &dcshuntwithspeed_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&dcshuntwithspeed_M->solverInfo, (&rtmGetErrorStatus
      (dcshuntwithspeed_M)));
    rtsiSetRTModelPtr(&dcshuntwithspeed_M->solverInfo, dcshuntwithspeed_M);
  }

  rtsiSetSimTimeStep(&dcshuntwithspeed_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&dcshuntwithspeed_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(dcshuntwithspeed_M, &dcshuntwithspeed_M->Timing.tArray[0]);
  rtmSetTFinal(dcshuntwithspeed_M, 10.0);
  dcshuntwithspeed_M->Timing.stepSize0 = 0.001;

  /* External mode info */
  dcshuntwithspeed_M->Sizes.checksums[0] = (2350455408U);
  dcshuntwithspeed_M->Sizes.checksums[1] = (2854388066U);
  dcshuntwithspeed_M->Sizes.checksums[2] = (4051654640U);
  dcshuntwithspeed_M->Sizes.checksums[3] = (3389688510U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    dcshuntwithspeed_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(dcshuntwithspeed_M->extModeInfo,
      &dcshuntwithspeed_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(dcshuntwithspeed_M->extModeInfo,
                        dcshuntwithspeed_M->Sizes.checksums);
    rteiSetTPtr(dcshuntwithspeed_M->extModeInfo, rtmGetTPtr(dcshuntwithspeed_M));
  }

  /* block I/O */
  (void) memset(((void *) &dcshuntwithspeed_B), 0,
                sizeof(B_dcshuntwithspeed_T));

  /* states (dwork) */
  (void) memset((void *)&dcshuntwithspeed_DW, 0,
                sizeof(DW_dcshuntwithspeed_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    dcshuntwithspeed_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* Start for S-Function (c2802xadc): '<Root>/armaturecurrent1' */
  InitAdc();
  config_ADC_SOC0 ();

  /* Start for S-Function (c2802xadc): '<Root>/line current ' */
  config_ADC_SOC2 ();

  /* Start for S-Function (c2802xadc): '<Root>/voltage' */
  config_ADC_SOC1 ();
}

/* Model terminate function */
void dcshuntwithspeed_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
