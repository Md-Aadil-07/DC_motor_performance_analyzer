// Created on 28-Mar-2019 14:55:22
#ifndef RTIOSTREAM_SERIAL_C28X_EXT_H_
#define RTIOSTREAM_SERIAL_C28X_EXT_H_

#include "MW_target_hardware_resources.h"

// Baud Rate = 115385
#define MW_PIL_SCIHBAUD 0
#define MW_PIL_SCILBAUD 64

#endif
