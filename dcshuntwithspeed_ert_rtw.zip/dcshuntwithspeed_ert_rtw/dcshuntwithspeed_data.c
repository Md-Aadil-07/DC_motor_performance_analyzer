/*
 * File: dcshuntwithspeed_data.c
 *
 * Code generated for Simulink model 'dcshuntwithspeed'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Thu Mar 28 14:55:16 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "dcshuntwithspeed.h"
#include "dcshuntwithspeed_private.h"

/* Block parameters (auto storage) */
P_dcshuntwithspeed_T dcshuntwithspeed_P = {
  1500.0,                              /* Expression: [1500]
                                        * Referenced by: '<Root>/speed'
                                        */
  0.104,                               /* Expression: 0.104
                                        * Referenced by: '<Root>/RPS'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<Root>/Radius'
                                        */
  1.2,                                 /* Expression: 1.2
                                        * Referenced by: '<Root>/Thickness'
                                        */
  9.81,                                /* Expression: 9.81
                                        * Referenced by: '<Root>/gain'
                                        */
  1.0,                                 /* Expression: [1]
                                        * Referenced by: '<Root>/Load1'
                                        */
  4.0,                                 /* Expression: [4]
                                        * Referenced by: '<Root>/Load2'
                                        */
  0.325                                /* Expression: 0.325
                                        * Referenced by: '<Root>/gain1'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
