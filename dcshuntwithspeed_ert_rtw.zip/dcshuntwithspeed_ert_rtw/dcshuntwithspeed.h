/*
 * File: dcshuntwithspeed.h
 *
 * Code generated for Simulink model 'dcshuntwithspeed'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Thu Mar 28 14:55:16 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_dcshuntwithspeed_h_
#define RTW_HEADER_dcshuntwithspeed_h_
#include <math.h>
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef dcshuntwithspeed_COMMON_INCLUDES_
# define dcshuntwithspeed_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "F2802x_Device.h"
#include "f2802x_examples.h"
#endif                                 /* dcshuntwithspeed_COMMON_INCLUDES_ */

#include "dcshuntwithspeed_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

extern void enable_interrupts(void);

/* Block signals (auto storage) */
typedef struct {
  real_T speed;                        /* '<Root>/speed' */
  real_T Torque;                       /* '<Root>/Torque' */
  real_T Product1;                     /* '<Root>/Product1' */
  real_T Divide;                       /* '<Root>/Divide' */
  real_T linecurrent;                  /* '<Root>/line current ' */
  real_T gain1;                        /* '<Root>/gain1' */
  real_T voltage;                      /* '<Root>/voltage' */
  real_T Product;                      /* '<Root>/Product' */
  real_T Divide1;                      /* '<Root>/Divide1' */
  real_T Clock;                        /* '<Root>/Clock' */
  uint16_T armaturecurrent1;           /* '<Root>/armaturecurrent1' */
} B_dcshuntwithspeed_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  struct {
    void *LoggedData;
  } Eb_PWORK;                          /* '<Root>/Eb' */

  struct {
    void *LoggedData[4];
  } Eb1_PWORK;                         /* '<Root>/Eb1' */

  struct {
    void *LoggedData;
  } Outputpwr_PWORK;                   /* '<Root>/Outputpwr' */

  struct {
    void *LoggedData;
  } changeininputpwr_PWORK;            /* '<Root>/change in input pwr ' */

  struct {
    void *LoggedData;
  } changeinoppwr_PWORK;               /* '<Root>/change in oppwr' */

  struct {
    void *LoggedData;
  } changeinspeed_PWORK;               /* '<Root>/change in speed' */

  struct {
    void *LoggedData;
  } changeintorqe_PWORK;               /* '<Root>/change in torqe' */

  struct {
    void *LoggedData;
  } eff_PWORK;                         /* '<Root>/eff' */

  struct {
    void *LoggedData[2];
  } inputpwr1_PWORK;                   /* '<Root>/inputpwr1' */

  struct {
    void *LoggedData;
  } Ttime_PWORK;                       /* '<Root>/Ttime' */
} DW_dcshuntwithspeed_T;

/* Parameters (auto storage) */
struct P_dcshuntwithspeed_T_ {
  real_T speed_Value;                  /* Expression: [1500]
                                        * Referenced by: '<Root>/speed'
                                        */
  real_T RPS_Gain;                     /* Expression: 0.104
                                        * Referenced by: '<Root>/RPS'
                                        */
  real_T Radius_Value;                 /* Expression: 0.5
                                        * Referenced by: '<Root>/Radius'
                                        */
  real_T Thickness_Value;              /* Expression: 1.2
                                        * Referenced by: '<Root>/Thickness'
                                        */
  real_T gain_Gain;                    /* Expression: 9.81
                                        * Referenced by: '<Root>/gain'
                                        */
  real_T Load1_Value;                  /* Expression: [1]
                                        * Referenced by: '<Root>/Load1'
                                        */
  real_T Load2_Value;                  /* Expression: [4]
                                        * Referenced by: '<Root>/Load2'
                                        */
  real_T gain1_Gain;                   /* Expression: 0.325
                                        * Referenced by: '<Root>/gain1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_dcshuntwithspeed_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (auto storage) */
extern P_dcshuntwithspeed_T dcshuntwithspeed_P;

/* Block signals (auto storage) */
extern B_dcshuntwithspeed_T dcshuntwithspeed_B;

/* Block states (auto storage) */
extern DW_dcshuntwithspeed_T dcshuntwithspeed_DW;

/* Model entry point functions */
extern void dcshuntwithspeed_initialize(void);
extern void dcshuntwithspeed_step(void);
extern void dcshuntwithspeed_terminate(void);

/* Real-time Model object */
extern RT_MODEL_dcshuntwithspeed_T *const dcshuntwithspeed_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'dcshuntwithspeed'
 */
#endif                                 /* RTW_HEADER_dcshuntwithspeed_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
