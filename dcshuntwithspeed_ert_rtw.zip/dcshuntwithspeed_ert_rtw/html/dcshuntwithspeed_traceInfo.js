function RTW_Sid2UrlHash() {
	this.urlHashMap = new Array();
	/* <Root>/Abs */
	this.urlHashMap["dcshuntwithspeed:1"] = "dcshuntwithspeed.c:37";
	/* <Root>/Add */
	this.urlHashMap["dcshuntwithspeed:2"] = "dcshuntwithspeed.c:43";
	/* <Root>/Clock */
	this.urlHashMap["dcshuntwithspeed:3"] = "dcshuntwithspeed.c:99&dcshuntwithspeed.h:91";
	/* <Root>/Divide */
	this.urlHashMap["dcshuntwithspeed:5"] = "dcshuntwithspeed.c:65&dcshuntwithspeed.h:85";
	/* <Root>/Divide1 */
	this.urlHashMap["dcshuntwithspeed:39"] = "dcshuntwithspeed.c:95&dcshuntwithspeed.h:90";
	/* <Root>/Eb */
	this.urlHashMap["dcshuntwithspeed:6"] = "dcshuntwithspeed.h:99";
	/* <Root>/Eb1 */
	this.urlHashMap["dcshuntwithspeed:7"] = "dcshuntwithspeed.h:103";
	/* <Root>/Inputpwr */
	this.urlHashMap["dcshuntwithspeed:8"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=dcshuntwithspeed:8";
	/* <Root>/Inputpwr1 */
	this.urlHashMap["dcshuntwithspeed:9"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=dcshuntwithspeed:9";
	/* <Root>/Inputpwr2 */
	this.urlHashMap["dcshuntwithspeed:10"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=dcshuntwithspeed:10";
	/* <Root>/Inputpwr3 */
	this.urlHashMap["dcshuntwithspeed:11"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=dcshuntwithspeed:11";
	/* <Root>/Load1 */
	this.urlHashMap["dcshuntwithspeed:12"] = "dcshuntwithspeed.c:38&dcshuntwithspeed.h:156&dcshuntwithspeed_data.c:37";
	/* <Root>/Load2 */
	this.urlHashMap["dcshuntwithspeed:13"] = "dcshuntwithspeed.c:39&dcshuntwithspeed.h:159&dcshuntwithspeed_data.c:40";
	/* <Root>/Outputpwr */
	this.urlHashMap["dcshuntwithspeed:14"] = "dcshuntwithspeed.h:107";
	/* <Root>/Outputpwr
 */
	this.urlHashMap["dcshuntwithspeed:15"] = "msg=rtwMsg_CodeGenerationReducedBlock&block=dcshuntwithspeed:15";
	/* <Root>/Product */
	this.urlHashMap["dcshuntwithspeed:16"] = "dcshuntwithspeed.c:91&dcshuntwithspeed.h:89";
	/* <Root>/Product1 */
	this.urlHashMap["dcshuntwithspeed:17"] = "dcshuntwithspeed.c:50&dcshuntwithspeed.h:84";
	/* <Root>/RPS */
	this.urlHashMap["dcshuntwithspeed:18"] = "dcshuntwithspeed.c:51&dcshuntwithspeed.h:144&dcshuntwithspeed_data.c:25";
	/* <Root>/Radius */
	this.urlHashMap["dcshuntwithspeed:19"] = "dcshuntwithspeed.c:40&dcshuntwithspeed.h:147&dcshuntwithspeed_data.c:28";
	/* <Root>/Subtract */
	this.urlHashMap["dcshuntwithspeed:20"] = "dcshuntwithspeed.c:44";
	/* <Root>/Thickness */
	this.urlHashMap["dcshuntwithspeed:21"] = "dcshuntwithspeed.c:41&dcshuntwithspeed.h:150&dcshuntwithspeed_data.c:31";
	/* <Root>/Torque */
	this.urlHashMap["dcshuntwithspeed:22"] = "dcshuntwithspeed.c:36&dcshuntwithspeed.h:83";
	/* <Root>/Ttime */
	this.urlHashMap["dcshuntwithspeed:23"] = "dcshuntwithspeed.h:135";
	/* <Root>/armaturecurrent1 */
	this.urlHashMap["dcshuntwithspeed:24"] = "dcshuntwithspeed.c:56,219&dcshuntwithspeed.h:92";
	/* <Root>/change in input pwr
 */
	this.urlHashMap["dcshuntwithspeed:25"] = "dcshuntwithspeed.h:111";
	/* <Root>/change in oppwr */
	this.urlHashMap["dcshuntwithspeed:26"] = "dcshuntwithspeed.h:115";
	/* <Root>/change in speed */
	this.urlHashMap["dcshuntwithspeed:27"] = "dcshuntwithspeed.h:119";
	/* <Root>/change in torqe */
	this.urlHashMap["dcshuntwithspeed:28"] = "dcshuntwithspeed.h:123";
	/* <Root>/eff */
	this.urlHashMap["dcshuntwithspeed:38"] = "dcshuntwithspeed.h:127";
	/* <Root>/gain */
	this.urlHashMap["dcshuntwithspeed:29"] = "dcshuntwithspeed.c:42&dcshuntwithspeed.h:153&dcshuntwithspeed_data.c:34";
	/* <Root>/gain1 */
	this.urlHashMap["dcshuntwithspeed:30"] = "dcshuntwithspeed.c:78&dcshuntwithspeed.h:87,162&dcshuntwithspeed_data.c:43";
	/* <Root>/inputpwr1 */
	this.urlHashMap["dcshuntwithspeed:31"] = "dcshuntwithspeed.h:131";
	/* <Root>/line current
 */
	this.urlHashMap["dcshuntwithspeed:33"] = "dcshuntwithspeed.c:69,223&dcshuntwithspeed.h:86";
	/* <Root>/speed */
	this.urlHashMap["dcshuntwithspeed:35"] = "dcshuntwithspeed.c:33&dcshuntwithspeed.h:82,141&dcshuntwithspeed_data.c:22";
	/* <Root>/voltage */
	this.urlHashMap["dcshuntwithspeed:37"] = "dcshuntwithspeed.c:82,226&dcshuntwithspeed.h:88";
	this.getUrlHash = function(sid) { return this.urlHashMap[sid];}
}
RTW_Sid2UrlHash.instance = new RTW_Sid2UrlHash();
function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "dcshuntwithspeed"};
	this.sidHashMap["dcshuntwithspeed"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/Abs"] = {sid: "dcshuntwithspeed:1"};
	this.sidHashMap["dcshuntwithspeed:1"] = {rtwname: "<Root>/Abs"};
	this.rtwnameHashMap["<Root>/Add"] = {sid: "dcshuntwithspeed:2"};
	this.sidHashMap["dcshuntwithspeed:2"] = {rtwname: "<Root>/Add"};
	this.rtwnameHashMap["<Root>/Clock"] = {sid: "dcshuntwithspeed:3"};
	this.sidHashMap["dcshuntwithspeed:3"] = {rtwname: "<Root>/Clock"};
	this.rtwnameHashMap["<Root>/Divide"] = {sid: "dcshuntwithspeed:5"};
	this.sidHashMap["dcshuntwithspeed:5"] = {rtwname: "<Root>/Divide"};
	this.rtwnameHashMap["<Root>/Divide1"] = {sid: "dcshuntwithspeed:39"};
	this.sidHashMap["dcshuntwithspeed:39"] = {rtwname: "<Root>/Divide1"};
	this.rtwnameHashMap["<Root>/Eb"] = {sid: "dcshuntwithspeed:6"};
	this.sidHashMap["dcshuntwithspeed:6"] = {rtwname: "<Root>/Eb"};
	this.rtwnameHashMap["<Root>/Eb1"] = {sid: "dcshuntwithspeed:7"};
	this.sidHashMap["dcshuntwithspeed:7"] = {rtwname: "<Root>/Eb1"};
	this.rtwnameHashMap["<Root>/Inputpwr"] = {sid: "dcshuntwithspeed:8"};
	this.sidHashMap["dcshuntwithspeed:8"] = {rtwname: "<Root>/Inputpwr"};
	this.rtwnameHashMap["<Root>/Inputpwr1"] = {sid: "dcshuntwithspeed:9"};
	this.sidHashMap["dcshuntwithspeed:9"] = {rtwname: "<Root>/Inputpwr1"};
	this.rtwnameHashMap["<Root>/Inputpwr2"] = {sid: "dcshuntwithspeed:10"};
	this.sidHashMap["dcshuntwithspeed:10"] = {rtwname: "<Root>/Inputpwr2"};
	this.rtwnameHashMap["<Root>/Inputpwr3"] = {sid: "dcshuntwithspeed:11"};
	this.sidHashMap["dcshuntwithspeed:11"] = {rtwname: "<Root>/Inputpwr3"};
	this.rtwnameHashMap["<Root>/Load1"] = {sid: "dcshuntwithspeed:12"};
	this.sidHashMap["dcshuntwithspeed:12"] = {rtwname: "<Root>/Load1"};
	this.rtwnameHashMap["<Root>/Load2"] = {sid: "dcshuntwithspeed:13"};
	this.sidHashMap["dcshuntwithspeed:13"] = {rtwname: "<Root>/Load2"};
	this.rtwnameHashMap["<Root>/Outputpwr"] = {sid: "dcshuntwithspeed:14"};
	this.sidHashMap["dcshuntwithspeed:14"] = {rtwname: "<Root>/Outputpwr"};
	this.rtwnameHashMap["<Root>/Outputpwr "] = {sid: "dcshuntwithspeed:15"};
	this.sidHashMap["dcshuntwithspeed:15"] = {rtwname: "<Root>/Outputpwr "};
	this.rtwnameHashMap["<Root>/Product"] = {sid: "dcshuntwithspeed:16"};
	this.sidHashMap["dcshuntwithspeed:16"] = {rtwname: "<Root>/Product"};
	this.rtwnameHashMap["<Root>/Product1"] = {sid: "dcshuntwithspeed:17"};
	this.sidHashMap["dcshuntwithspeed:17"] = {rtwname: "<Root>/Product1"};
	this.rtwnameHashMap["<Root>/RPS"] = {sid: "dcshuntwithspeed:18"};
	this.sidHashMap["dcshuntwithspeed:18"] = {rtwname: "<Root>/RPS"};
	this.rtwnameHashMap["<Root>/Radius"] = {sid: "dcshuntwithspeed:19"};
	this.sidHashMap["dcshuntwithspeed:19"] = {rtwname: "<Root>/Radius"};
	this.rtwnameHashMap["<Root>/Subtract"] = {sid: "dcshuntwithspeed:20"};
	this.sidHashMap["dcshuntwithspeed:20"] = {rtwname: "<Root>/Subtract"};
	this.rtwnameHashMap["<Root>/Thickness"] = {sid: "dcshuntwithspeed:21"};
	this.sidHashMap["dcshuntwithspeed:21"] = {rtwname: "<Root>/Thickness"};
	this.rtwnameHashMap["<Root>/Torque"] = {sid: "dcshuntwithspeed:22"};
	this.sidHashMap["dcshuntwithspeed:22"] = {rtwname: "<Root>/Torque"};
	this.rtwnameHashMap["<Root>/Ttime"] = {sid: "dcshuntwithspeed:23"};
	this.sidHashMap["dcshuntwithspeed:23"] = {rtwname: "<Root>/Ttime"};
	this.rtwnameHashMap["<Root>/armaturecurrent1"] = {sid: "dcshuntwithspeed:24"};
	this.sidHashMap["dcshuntwithspeed:24"] = {rtwname: "<Root>/armaturecurrent1"};
	this.rtwnameHashMap["<Root>/change in input pwr "] = {sid: "dcshuntwithspeed:25"};
	this.sidHashMap["dcshuntwithspeed:25"] = {rtwname: "<Root>/change in input pwr "};
	this.rtwnameHashMap["<Root>/change in oppwr"] = {sid: "dcshuntwithspeed:26"};
	this.sidHashMap["dcshuntwithspeed:26"] = {rtwname: "<Root>/change in oppwr"};
	this.rtwnameHashMap["<Root>/change in speed"] = {sid: "dcshuntwithspeed:27"};
	this.sidHashMap["dcshuntwithspeed:27"] = {rtwname: "<Root>/change in speed"};
	this.rtwnameHashMap["<Root>/change in torqe"] = {sid: "dcshuntwithspeed:28"};
	this.sidHashMap["dcshuntwithspeed:28"] = {rtwname: "<Root>/change in torqe"};
	this.rtwnameHashMap["<Root>/eff"] = {sid: "dcshuntwithspeed:38"};
	this.sidHashMap["dcshuntwithspeed:38"] = {rtwname: "<Root>/eff"};
	this.rtwnameHashMap["<Root>/gain"] = {sid: "dcshuntwithspeed:29"};
	this.sidHashMap["dcshuntwithspeed:29"] = {rtwname: "<Root>/gain"};
	this.rtwnameHashMap["<Root>/gain1"] = {sid: "dcshuntwithspeed:30"};
	this.sidHashMap["dcshuntwithspeed:30"] = {rtwname: "<Root>/gain1"};
	this.rtwnameHashMap["<Root>/inputpwr1"] = {sid: "dcshuntwithspeed:31"};
	this.sidHashMap["dcshuntwithspeed:31"] = {rtwname: "<Root>/inputpwr1"};
	this.rtwnameHashMap["<Root>/line current "] = {sid: "dcshuntwithspeed:33"};
	this.sidHashMap["dcshuntwithspeed:33"] = {rtwname: "<Root>/line current "};
	this.rtwnameHashMap["<Root>/speed"] = {sid: "dcshuntwithspeed:35"};
	this.sidHashMap["dcshuntwithspeed:35"] = {rtwname: "<Root>/speed"};
	this.rtwnameHashMap["<Root>/voltage"] = {sid: "dcshuntwithspeed:37"};
	this.sidHashMap["dcshuntwithspeed:37"] = {rtwname: "<Root>/voltage"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
