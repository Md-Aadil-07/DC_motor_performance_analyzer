/*
 * File: dcshuntwithspeed_types.h
 *
 * Code generated for Simulink model 'dcshuntwithspeed'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 8.12 (R2017a) 16-Feb-2017
 * C/C++ source code generated on : Thu Mar 28 14:55:16 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_dcshuntwithspeed_types_h_
#define RTW_HEADER_dcshuntwithspeed_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct P_dcshuntwithspeed_T_ P_dcshuntwithspeed_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_dcshuntwithspeed_T RT_MODEL_dcshuntwithspeed_T;

#endif                                 /* RTW_HEADER_dcshuntwithspeed_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
